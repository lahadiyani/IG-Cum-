###  Cara Install Di Termux
    $ pkg pkg update && upgrade
    $ pkg install python
    $ pkg install git
    $ pip install requests rich httpx --user
    $ git clone https://github.com/khamdihi-dev/DMBFI
    $ cd DMBFI
    $ python3 Instagram.py
### Sosial Media
[![](https://img.shields.io/badge/Instagram-pink?logo=Instagram&logoColor=pink&labelColor=white)](https://www.instagram.com/cython.id)
[![](https://img.shields.io/badge/Whatsapp-white?logo=Whatsapp&logoColor=Brightgreen&labelColor=white)](https://wa.me/6285729416714?text=Asalamualaikum+bang)<br>





